"""
南开大学可视化课程抽签系统后端
Flask + 线程锁处理并发
"""
import csv
import random
import threading
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 处理跨域

# 全局锁，防止并发冲突
draw_lock = threading.Lock()

# 数据存储
groups_data = {}  # {group_name: number}
available_numbers = []  # 可用序号池

def load_groups():
    """从CSV加载队伍数据"""
    global groups_data, available_numbers
    groups_data = {}
    
    with open('../groups.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            group_name = row['group name'].strip()
            number = row['number'].strip() if row['number'] else None
            groups_data[group_name] = int(number) if number else None
    
    # 计算可用序号
    total_groups = len(groups_data)
    used_numbers = {v for v in groups_data.values() if v is not None}
    available_numbers = [i for i in range(1, total_groups + 1) if i not in used_numbers]
    random.shuffle(available_numbers)

def save_groups():
    """保存队伍数据到CSV"""
    with open('../groups.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['group name', 'number'])
        for name, number in groups_data.items():
            writer.writerow([name, number if number else ''])

# 启动时加载数据
load_groups()

@app.route('/api/team-names', methods=['GET'])
def get_team_names():
    """获取所有队伍名称（用于自动补全）"""
    with draw_lock:
        return jsonify({
            'success': True,
            'names': list(groups_data.keys())
        })

@app.route('/api/groups', methods=['GET'])
def get_groups():
    """获取所有队伍及抽签状态"""
    with draw_lock:
        result = []
        for name, number in groups_data.items():
            result.append({
                'name': name,
                'number': number,
                'drawn': number is not None
            })
        # 按序号排序，未抽签的放最后
        result.sort(key=lambda x: (x['number'] is None, x['number'] if x['number'] else 999))
        return jsonify({
            'success': True,
            'groups': result,
            'total': len(result),
            'drawn_count': sum(1 for g in result if g['drawn']),
            'remaining': len(available_numbers)
        })

@app.route('/api/check', methods=['POST'])
def check_group():
    """检查队伍是否存在及抽签状态"""
    data = request.get_json()
    group_name = data.get('name', '').strip()
    
    with draw_lock:
        if group_name not in groups_data:
            return jsonify({
                'success': False,
                'error': '队伍名称不存在，请检查输入'
            })
        
        number = groups_data[group_name]
        if number is not None:
            return jsonify({
                'success': True,
                'already_drawn': True,
                'number': number,
                'message': f'你们队已经抽过签了，序号是 {number}'
            })
        
        return jsonify({
            'success': True,
            'already_drawn': False,
            'message': '可以抽签'
        })

@app.route('/api/draw', methods=['POST'])
def draw_number():
    """为队伍抽签"""
    data = request.get_json()
    group_name = data.get('name', '').strip()
    
    with draw_lock:
        # 验证队伍
        if group_name not in groups_data:
            return jsonify({
                'success': False,
                'error': '队伍名称不存在'
            })
        
        # 检查是否已抽签
        if groups_data[group_name] is not None:
            return jsonify({
                'success': False,
                'error': '该队伍已经抽过签了',
                'number': groups_data[group_name]
            })
        
        # 检查是否还有可用序号
        if not available_numbers:
            return jsonify({
                'success': False,
                'error': '所有序号已被抽完'
            })
        
        # 抽取序号
        number = available_numbers.pop()
        groups_data[group_name] = number
        
        # 保存到文件
        save_groups()
        
        return jsonify({
            'success': True,
            'number': number,
            'message': f'恭喜！你们抽到的序号是 {number}'
        })

@app.route('/api/reset', methods=['POST'])
def reset_all():
    """重置所有抽签结果（管理员功能）"""
    password = request.get_json().get('password', '')
    if password != '1207':
        return jsonify({'success': False, 'error': '密码错误'})
    
    with draw_lock:
        for name in groups_data:
            groups_data[name] = None
        available_numbers.clear()
        available_numbers.extend(range(1, len(groups_data) + 1))
        random.shuffle(available_numbers)
        save_groups()
        return jsonify({'success': True, 'message': '已重置所有抽签结果'})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """获取统计信息"""
    with draw_lock:
        total = len(groups_data)
        drawn = sum(1 for v in groups_data.values() if v is not None)
        return jsonify({
            'total': total,
            'drawn': drawn,
            'remaining': total - drawn
        })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
