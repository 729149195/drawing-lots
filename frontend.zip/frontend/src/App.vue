<template>
  <div class="mesh-bg"></div>
  <div class="noise-overlay"></div>
  
  <div class="app-container">
    <!-- 极简导航 -->
    <nav class="nav-bar">
      <router-link to="/" class="nav-link">抽签</router-link>
      <router-link to="/admin" class="nav-link">结果公示</router-link>
    </nav>

    <!-- 页面内容 -->
    <div class="page-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </div>
  </div>
</template>

<script setup>
</script>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(10px);
}
</style>
