<template>
  <div class="admin-page">
    <div class="page-title">
      <h1 class="display-title">抽签看板</h1>
      <p class="subtitle">实时数据监控</p>
    </div>

    <div class="admin-container">
      <!-- 统计条 -->
      <div class="stats-bar">
        <div class="stat-item">
          <div class="stat-val">{{ stats.total }}</div>
          <div class="stat-label">总队伍数</div>
        </div>
        <div class="stat-item">
          <div class="stat-val" style="color: var(--accent-cyan);">{{ stats.drawn }}</div>
          <div class="stat-label">已抽签</div>
        </div>
        <div class="stat-item">
          <div class="stat-val" style="color: var(--accent-pink);">{{ stats.remaining }}</div>
          <div class="stat-label">未抽签</div>
        </div>
      </div>

      <!-- 刷新按钮 -->
      <div style="text-align: center; margin-bottom: 40px;">
        <button class="btn btn-secondary" @click="fetchGroups" :disabled="loading">
          {{ loading ? '刷新中...' : '刷新数据' }}
        </button>
      </div>

      <!-- 队伍网格 -->
      <div v-if="loading && !groups.length" style="text-align: center; padding: 40px;">
        加载中...
      </div>

      <div v-else class="groups-grid">
        <div
          v-for="group in groups"
          :key="group.name"
          class="group-card"
          :class="{ drawn: group.drawn }"
        >
          <span class="group-name">{{ group.name }}</span>
          <span class="group-number">
            {{ group.drawn ? group.number : '-' }}
          </span>
        </div>
      </div>

      <!-- 管理员重置 -->
      <div style="margin-top: 60px; text-align: center; opacity: 0.3; transition: opacity 0.3s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.3">
        <button 
          class="btn btn-secondary" 
          style="border: 1px solid #ef4444; color: #ef4444;"
          @click="showResetModal = true"
        >
          重置所有数据
        </button>
      </div>
    </div>

    <!-- 重置确认弹窗 -->
    <div v-if="showResetModal" class="modal-overlay" @click.self="showResetModal = false">
      <div class="glass-card" style="max-width: 400px; text-align: center;">
        <h3 style="font-size: 1.5rem; margin-bottom: 20px; font-weight: 800;">警告操作</h3>
        <p style="color: var(--text-secondary); margin-bottom: 30px;">
          此操作将清空所有抽签结果，不可恢复。请输入管理员密码确认。
        </p>
        <div class="input-wrapper" style="margin-bottom: 20px;">
          <input
            v-model="resetPassword"
            type="password"
            class="giant-input"
            style="font-size: 1.5rem;"
            placeholder="管理员密码"
          />
        </div>
        <div v-if="resetError" style="color: #ef4444; margin-bottom: 20px;">
          {{ resetError }}
        </div>
        <div style="display: flex; gap: 15px;">
          <button class="btn btn-secondary" @click="showResetModal = false" style="flex: 1;">取消</button>
          <button class="btn" @click="doReset" style="background: #ef4444; color: white; flex: 1;">确认重置</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import axios from 'axios'

const API_BASE = '/api'

const groups = ref([])
const stats = ref({ total: 0, drawn: 0, remaining: 0 })
const loading = ref(false)
const showResetModal = ref(false)
const resetPassword = ref('')
const resetError = ref('')

let refreshInterval = null

// 获取队伍数据
async function fetchGroups() {
  loading.value = true
  try {
    const response = await axios.get(`${API_BASE}/groups`)
    if (response.data.success) {
      groups.value = response.data.groups
      stats.value = {
        total: response.data.total,
        drawn: response.data.drawn_count,
        remaining: response.data.remaining
      }
    }
  } catch (error) {
    console.error('Failed to fetch data:', error)
  }
  loading.value = false
}

// 重置所有
async function doReset() {
  resetError.value = ''
  try {
    const response = await axios.post(`${API_BASE}/reset`, {
      password: resetPassword.value
    })
    if (response.data.success) {
      showResetModal.value = false
      resetPassword.value = ''
      fetchGroups()
    } else {
      resetError.value = response.data.error
    }
  } catch (error) {
    resetError.value = 'Operation failed'
  }
}

onMounted(() => {
  fetchGroups()
  // 自动刷新
  refreshInterval = setInterval(fetchGroups, 5000)
})

onUnmounted(() => {
  if (refreshInterval) {
    clearInterval(refreshInterval)
  }
})
</script>

<style scoped>
.admin-page {
  width: 100%;
  padding-bottom: 60px;
}
</style>
