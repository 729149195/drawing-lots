<template>
  <div class="draw-page">
    <!-- 标题 -->
    <div class="page-title">
      <h1 class="display-title">南开可视化</h1>
      <p class="subtitle">小组展示顺序抽签</p>
    </div>

    <!-- 抽签卡片 -->
    <div class="glass-card">
      <!-- 初始状态：输入队名 -->
      <template v-if="state === 'input'">
        <div class="input-wrapper">
          <div class="autocomplete-wrapper">
            <input
              ref="inputRef"
              v-model="teamName"
              type="text"
              class="giant-input"
              placeholder="请输入队伍名称"
              autocomplete="off"
              @input="onInput"
              @focus="onFocus"
              @blur="onBlur"
              @keydown.down.prevent="onArrowDown"
              @keydown.up.prevent="onArrowUp"
              @keydown.enter.prevent="onEnter"
              @keydown.escape="closeDropdown"
            />
            <!-- 下拉列表 -->
            <div v-if="showDropdown && filteredTeams.length" class="dropdown-list">
              <div
                v-for="(team, index) in filteredTeams"
                :key="team"
                class="dropdown-item"
                :class="{ active: index === selectedIndex }"
                @mousedown.prevent="selectTeam(team)"
              >
                {{ team }}
              </div>
            </div>
          </div>
        </div>

        <div v-if="errorMessage" class="message message-error" style="margin-bottom: 30px;">
          {{ errorMessage }}
        </div>

        <div style="text-align: center;">
          <button
            class="btn"
            :disabled="!teamName.trim() || loading"
            @click="checkTeam"
          >
            <span v-if="loading">查询中...</span>
            <span v-else>查询状态 →</span>
          </button>
        </div>
      </template>

      <!-- 确认抽签 -->
      <template v-else-if="state === 'confirm'">
        <div style="text-align: center;">
          <p style="color: var(--text-secondary); margin-bottom: 10px; letter-spacing: 2px;">确认队伍信息</p>
          <h2 style="font-size: 2rem; margin-bottom: 40px; font-weight: 900;">{{ teamName }}</h2>
        </div>

        <div style="display: flex; gap: 20px; justify-content: center;">
          <button class="btn btn-secondary" @click="resetState">
            返回修改
          </button>
          <button class="btn" @click="startDraw">
            开始抽签
          </button>
        </div>
      </template>

      <!-- 抽签动画 -->
      <template v-else-if="state === 'drawing'">
        <div class="drawing-animation">
          <div class="csgo-roller" ref="rollerContainerRef">
            <div class="roller-pointer"></div>
            <div class="roller-mask">
              <div class="roller-strip" :style="rollerStyle">
                <div 
                  v-for="(item, index) in rollItems" 
                  :key="index" 
                  class="roller-item"
                  :class="{ 'winning-item': index === winningIndex && showWinningEffect }"
                >
                  {{ item }}
                </div>
              </div>
            </div>
          </div>
          <p style="color: var(--text-secondary); letter-spacing: 4px; margin-top: 30px;">正在生成序号...</p>
        </div>
      </template>

      <!-- 显示结果 -->
      <template v-else-if="state === 'result'">
        <div style="text-align: center;">
          <p style="color: var(--text-secondary); letter-spacing: 2px;">您的展示顺序</p>
          <div class="result-huge">{{ result }}</div>
          <p style="font-size: 1.2rem; margin-bottom: 40px;">祝 {{ teamName }} 展示顺利！</p>
          
          <button class="btn btn-secondary" @click="resetState">
            完成
          </button>
        </div>
      </template>

      <!-- 已抽过签 -->
      <template v-else-if="state === 'already'">
        <div style="text-align: center;">
          <p style="color: var(--accent-pink); letter-spacing: 2px; margin-bottom: 10px;">已完成抽签</p>
          <div class="result-huge" style="filter: grayscale(1); opacity: 0.8;">{{ result }}</div>
          <p style="font-size: 1.2rem; margin-bottom: 40px;">{{ teamName }}</p>

          <button class="btn btn-secondary" @click="resetState">
            返回
          </button>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'

const API_BASE = '/api'

const teamName = ref('')
const state = ref('input') // input, confirm, drawing, result, already
const loading = ref(false)
const errorMessage = ref('')
const result = ref(null)
const rollItems = ref([])
const winningIndex = 65 // 增加列表长度，让滚动时间更长
const rollerStyle = ref({})
const rollerContainerRef = ref(null) // 容器引用
const itemTotalWidth = 140 // 120px width + 20px margin
const showWinningEffect = ref(false) // 控制中奖特效显示

// 自动补全相关
const inputRef = ref(null)
const allTeamNames = ref([])
const showDropdown = ref(false)
const selectedIndex = ref(-1)

// 过滤后的队伍列表
const filteredTeams = computed(() => {
  if (!teamName.value.trim()) {
    return allTeamNames.value.slice(0, 5) // 显示前5个
  }
  const query = teamName.value.toLowerCase()
  return allTeamNames.value
    .filter(name => name.toLowerCase().includes(query))
    .slice(0, 5)
})

// 获取所有队伍名称
async function fetchTeamNames() {
  try {
    const response = await axios.get(`${API_BASE}/team-names`)
    if (response.data.success) {
      allTeamNames.value = response.data.names
    }
  } catch (error) {
    console.error('获取队伍列表失败:', error)
  }
}

// 输入事件
function onInput() {
  showDropdown.value = true
  selectedIndex.value = -1
}

function onFocus() {
  showDropdown.value = true
}

function onBlur() {
  // 延迟关闭，以便点击事件能触发
  setTimeout(() => {
    showDropdown.value = false
  }, 150)
}

function onArrowDown() {
  if (selectedIndex.value < filteredTeams.value.length - 1) {
    selectedIndex.value++
  }
}

function onArrowUp() {
  if (selectedIndex.value > 0) {
    selectedIndex.value--
  }
}

function onEnter() {
  if (selectedIndex.value >= 0 && filteredTeams.value[selectedIndex.value]) {
    selectTeam(filteredTeams.value[selectedIndex.value])
  } else if (teamName.value.trim()) {
    checkTeam()
  }
}

function selectTeam(name) {
  teamName.value = name
  showDropdown.value = false
  selectedIndex.value = -1
}

function closeDropdown() {
  showDropdown.value = false
  selectedIndex.value = -1
}

// 重置状态
function resetState() {
  teamName.value = ''
  state.value = 'input'
  loading.value = false
  errorMessage.value = ''
  result.value = null
  selectedIndex.value = -1
}

onMounted(() => {
  fetchTeamNames()
})

// 检查队伍
async function checkTeam() {
  if (!teamName.value.trim()) return
  
  loading.value = true
  errorMessage.value = ''

  try {
    const response = await axios.post(`${API_BASE}/check`, {
      name: teamName.value.trim()
    })

    if (!response.data.success) {
      errorMessage.value = response.data.error
      loading.value = false
      return
    }

    if (response.data.already_drawn) {
      result.value = response.data.number
      state.value = 'already'
    } else {
      state.value = 'confirm'
    }
  } catch (error) {
    errorMessage.value = '网络请求错误'
  }

  loading.value = false
}

// 开始抽签
async function startDraw() {
  state.value = 'drawing'
  showWinningEffect.value = false
  
  // 生成初始随机列表 (更多项，确保滚动距离够长)
  rollItems.value = Array.from({ length: 80 }, () => Math.floor(Math.random() * 50) + 1)
  
  // 重置样式
  rollerStyle.value = {
    transform: 'translateX(0)',
    transition: 'none'
  }

  try {
    const response = await axios.post(`${API_BASE}/draw`, {
      name: teamName.value.trim()
    })

    if (response.data.success) {
      const winningNumber = response.data.number
      
      // 将结果放入预定位置
      rollItems.value[winningIndex] = winningNumber
      
      // 强制重绘后开始动画
      setTimeout(() => {
        if (!rollerContainerRef.value) return
        
        const containerWidth = rollerContainerRef.value.clientWidth
        const currentItemTotalWidth = window.innerWidth <= 768 ? 100 : 140
        
        const offset = (containerWidth / 2) - (currentItemTotalWidth / 2) - (winningIndex * currentItemTotalWidth)
        
        // 随机偏移 (±40% item width)，增加不确定性
        const maxRandom = currentItemTotalWidth * 0.4
        const randomOffset = Math.floor(Math.random() * (maxRandom * 2)) - maxRandom
        
        rollerStyle.value = {
          transform: `translateX(${offset + randomOffset}px)`,
          // CS:GO 风格曲线：快速启动 -> 极速滑行 -> 缓慢减速 -> 几乎静止
          transition: 'transform 8s cubic-bezier(0.15, 1, 0.3, 1)'
        }
      }, 50)

      // 等待动画结束
      await new Promise(resolve => setTimeout(resolve, 8500))
      
      // 动画结束后显示高亮特效
      showWinningEffect.value = true
      
      // 延迟一点再显示结果页，让用户欣赏一下结果
      await new Promise(resolve => setTimeout(resolve, 800))
      
      result.value = winningNumber
      state.value = 'result'
    } else {
      errorMessage.value = response.data.error
      if (response.data.number) {
        result.value = response.data.number
        state.value = 'already'
      } else {
        state.value = 'input'
      }
    }
  } catch (error) {
    console.error(error)
    errorMessage.value = '网络请求错误'
    state.value = 'input'
  }
}
</script>

<style scoped>
.draw-page {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* CS:GO 滚动条样式 */
.csgo-roller {
  position: relative;
  width: 100%;
  max-width: 600px;
  height: 150px; /* 增加高度 */
  margin: 0 auto;
  background: rgba(0, 0, 0, 0.3);
  border-radius: 12px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.6);
}

.roller-mask {
  width: 100%;
  height: 100%;
  overflow: hidden;
  /* 两侧遮罩渐变 */
  mask-image: linear-gradient(90deg, transparent, black 15%, black 85%, transparent);
  -webkit-mask-image: linear-gradient(90deg, transparent, black 15%, black 85%, transparent);
}

.roller-pointer {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 50%;
  width: 4px;
  background: #ffd700;
  transform: translateX(-50%);
  z-index: 10;
  box-shadow: 0 0 15px #ffd700, 0 0 5px #fff; /* 增强发光 */
}

/* 倒三角指针头 */
.roller-pointer::after {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-top: 15px solid #ffd700;
}

.roller-pointer::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 15px solid #ffd700;
}

.roller-strip {
  display: flex;
  align-items: center;
  height: 100%;
  will-change: transform;
  /* 移除初始 padding，完全靠 transform 定位 */
}

.roller-item {
  flex-shrink: 0;
  width: 120px; /* 增加宽度 */
  height: 120px; /* 增加高度 */
  margin: 0 10px; /* 增加间距 */
  background: linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.03));
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 3.5rem; /* 增加字号 */
  font-weight: 800;
  color: rgba(255, 255, 255, 0.9);
  font-variant-numeric: tabular-nums;
  text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

.winning-item {
  background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(139, 92, 246, 0.2));
  border: 2px solid #E040FB;
  color: #fff;
  text-shadow: 0 0 20px rgba(224, 64, 251, 0.6);
  box-shadow: inset 0 0 20px rgba(224, 64, 251, 0.2);
}

@media (max-width: 768px) {
  .csgo-roller {
    height: 120px;
  }
  
  .roller-item {
    width: 90px;
    height: 90px;
    font-size: 2.5rem;
    margin: 0 5px;
  }
  
  /* 移动端重新计算 itemTotalWidth 为 100px */
}

.confirm-info {
  margin-bottom: 10px;
}
</style>
